# Created by Andy at 03-Jan-21

# Enter description here

# ___________________________________

import pytest
import hypothesis
from genetic_algo import *


def test_initialise_raises_for_invalid_population(fails):
    solver = GASolver(obj_fn=None, population = 10000000)
    solver = GASolver(obj_fn=None, population = 3.65)
    solver = GASolver(obj_fn=None, population = 0)

def test_initialise_raises_for_invalid_p_mutation(fails):
    solver = GASolver(obj_fn=None, p_mutation=-0.3)
    solver = GASolver(obj_fn=None, p_mutation=2)

def test_initialise_raises_for_invalid_n_encoding(fails):
    solver = GASolver(obj_fn=None, n_encoding_bits=0)
    solver = GASolver(obj_fn=None, n_encoding_bits=40)

    solver = GASolver(obj_fn=None, n_encoding_bits=20.3)



@pytest.fixture()
def fails():
    with pytest.raises(Exception):
        yield